/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CONTROLLER;

import MODEL.BibliotecaDataLayerMysqlImpl;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.iw.framework.result.TemplateManagerException;
import org.iw.framework.result.TemplateResult;

/**
 *
 * @author h00k
 */
public class Search extends BibliotecaBaseControler {

    
    private void action_search_by_ISBN(HttpServletRequest request, HttpServletResponse response)
    {
        BibliotecaDataLayerMysqlImpl biblc = (BibliotecaDataLayerMysqlImpl)request.getAttribute("datalayer");   
       
    }
    private void action_search_base(HttpServletRequest request, HttpServletResponse response)
    {
        
    }
    
    private void action_default_search_advance(HttpServletRequest request, HttpServletResponse response) throws TemplateManagerException
    {
         TemplateResult template = new TemplateResult(getServletContext());
         template.activate("search_advance.ftl.html", request, response);
    }
    
    @Override
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    {
        try 
        {
            if(request.getParameter("searchBase")!= null)
                action_search_base(request,response);
            else if(request.getParameter("searchAdvance")!= null)
            {
                if(request.getParameter("tipo").equals("ISBN"))action_search_by_ISBN(request , response);
                
            }
                action_default_search_advance(request, response);
        }
        catch (TemplateManagerException ex) 
        {
            Logger.getLogger(Search.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public String getServletInfo() {
        return "Search Servlet";
    }
}
