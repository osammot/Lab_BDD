package CONTROLLER;

import MODEL.BibliotecaDataLayerMysqlImpl;
import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.iw.framework.result.TemplateManagerException;
import org.iw.framework.result.TemplateResult;
import org.iw.framework.security.SecurityLayer;

/**
 *
 * @author h00k
 */
public class Login extends BibliotecaBaseControler {

    /**
     * METDO CHE CONTROLLA SE SONO GIA' IN SESSIONE ; 
     * @param request
     * @param response
     * @return RITORNA DIRETTAMENTE IN HOME
     * @throws TemplateManagerException 
     */
    private void action_alreadyLog(HttpServletRequest request , HttpServletResponse response) throws TemplateManagerException, IOException
    {
         response.sendRedirect("Home");
    }
    /**
     * METODO CHE SE INSERITII EMAIL E PASSWORD CONTROLLA SE ESISTE UNA CORRISPONDENZA E EFFETTUA IL LOGIN
     * @param request
     * @param response
     * @throws TemplateManagerException
     * @throws SQLException
     * @throws IOException 
     */
    private void action_login(HttpServletRequest request, HttpServletResponse response) throws TemplateManagerException, SQLException, IOException
    {
        BibliotecaDataLayerMysqlImpl biblc = (BibliotecaDataLayerMysqlImpl)request.getAttribute("datalayer");  
        
        String email =  request.getParameter("email");
        String password =  request.getParameter("password");
                
        boolean isCorrect = biblc.login(email, password);
        
        if(isCorrect)
        {
            
            SecurityLayer.createSession(request, email);
         
            
            response.sendRedirect("Home");
        }
        else
            action_default(request, response);
    }
    
    /**
     * METODO DI DEFAULT CHE CARICA LA PAGINA LOGIN
     * @param request
     * @param response
     * @throws TemplateManagerException 
     */
    private void action_default(HttpServletRequest request, HttpServletResponse response) throws TemplateManagerException
    {
            TemplateResult template = new TemplateResult(getServletContext());
            template.activate("login.html", request, response);
    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    {
        try 
        {
            if(SecurityLayer.checkSession(request)!= null) action_alreadyLog(request, response);
            
            else {
                if(
                request.getParameter("email") != null && !(request.getParameter("email").isEmpty()) &&
                request.getParameter("password") != null && !(request.getParameter("password").isEmpty())
               )
                action_login(request,response);
            else
                action_default(request, response);
                    }
        
        
        } catch (TemplateManagerException ex) 
        {
            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public String getServletInfo() 
    {
        return "Login Servlet";
    }
}
