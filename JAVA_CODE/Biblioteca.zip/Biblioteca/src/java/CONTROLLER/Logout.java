/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CONTROLLER;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.iw.framework.security.SecurityLayer;

/**
 *
 * @author h00k
 */
public class Logout  extends BibliotecaBaseControler  {


   
    @Override
    public String getServletInfo() {
        return "Logout servlet";
    }// </editor-fold>

    
    private void action_logout(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
    {
        SecurityLayer.disposeSession(request);
        response.sendRedirect("Home");
    }
    @Override
    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException {
    
        try {
        
            if(SecurityLayer.checkSession(request)!= null)
                action_logout(request,response);
        
            else
                response.sendRedirect("Home");
        
        } catch (IOException ex) {
            Logger.getLogger(Logout.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
