package CONTROLLER;

import MODEL.Autore;
import MODEL.BibliotecaDataLayerMysqlImpl;
import MODEL.Edizione;
import MODEL.Pubblicazione;
import MODEL.Recensione;
import freemarker.template.TemplateException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.iw.framework.result.FailureResult;
import org.iw.framework.result.TemplateManagerException;
import org.iw.framework.result.TemplateResult;
import org.iw.framework.security.SecurityLayer;

/**
 *
 * @author h00k
 */

public class SinglePubblicazione extends BibliotecaBaseControler {
    
    private void action_like(HttpServletRequest request , HttpServletResponse response) throws SQLException, TemplateManagerException
    {
        System.out.println("ok dentro action_like");
        BibliotecaDataLayerMysqlImpl bibsql =  (BibliotecaDataLayerMysqlImpl)request.getAttribute("datalayer") ;
        String id = request.getParameter("like");
        bibsql.insertLike((String)SecurityLayer.checkSession(request).getAttribute("email"), Integer.parseInt(id));
        action_SinglePubblicazione(request, response);
    }
    
    private void action_inserRec(HttpServletRequest request, HttpServletResponse response) throws SQLException, TemplateManagerException
    {
        String pub= request.getParameter("idPubb");
        int id = Integer.parseInt(pub);
        
        BibliotecaDataLayerMysqlImpl bibsql =  (BibliotecaDataLayerMysqlImpl)request.getAttribute("datalayer") ;
        bibsql.insertRecesione(id , (String) SecurityLayer.checkSession(request).getAttribute("email"), request.getParameter("testo"));
        action_SinglePubblicazione(request, response);
    }
    
    
    private void action_SinglePubblicazione(HttpServletRequest request, HttpServletResponse response) throws SQLException, TemplateManagerException
    {
        TemplateResult template = new TemplateResult(getServletContext());
        BibliotecaDataLayerMysqlImpl bibsql =  (BibliotecaDataLayerMysqlImpl)request.getAttribute("datalayer") ;
        
        Pubblicazione pubb =  bibsql.getSinglePubblicazione(request.getParameter("titoloPubb"));
        List<Edizione> listaEdizione = bibsql.getEdizioniByTitolo(request.getParameter("titoloPubb"));
        List<Autore> listaAutore = bibsql.getAutoriPubblicazioneByTitolo(request.getParameter("titoloPubb"));
        List<Recensione> listaRecensione = bibsql.getRecensioniApprovate(request.getParameter("titoloPubb"));
     
        request.setAttribute("pubb", pubb);
        request.setAttribute("listaEdizione", listaEdizione);
        request.setAttribute("listaAutore", listaAutore);
        request.setAttribute("listaRecensione", listaRecensione);
        
        template.activate("singolaPubblicazione.html", request, response);
    }
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    {
        try 
        {   
            if(SecurityLayer.checkSession(request) != null)
            {
                if( request.getParameter("titoloPubb") != null && !(request.getParameter("titoloPubb").isEmpty()) &&
                    request.getParameter("idPubb") != null && !(request.getParameter("idPubb").isEmpty())
                   )
                {
                    action_inserRec(request, response);
                }
                else
                {
                    if(request.getParameter("like")!= null)
                    {
                        action_like(request, response);
                    }
                    action_SinglePubblicazione(request, response);
                }
            }
            else {
                if(request.getParameter("titoloPubb")!= null)
                    action_SinglePubblicazione(request, response);
                
            }
        }
        catch (SQLException | TemplateManagerException ex) 
        {
            try 
            {
                (new FailureResult(getServletContext())).activate(
                        (ex.getMessage() != null || ex.getCause() == null) ? ex.getMessage() : ex.getCause().getMessage(), request, response);
            } catch (IOException | TemplateException | TemplateManagerException ex1) {
                Logger.getLogger(SinglePubblicazione.class.getName()).log(Level.SEVERE, null, ex1);
            }
        } 
    }
    
    @Override
    public String getServletInfo() {
        return "Servlet Singola Pubblicazione";
    }// </editor-fold>

}
