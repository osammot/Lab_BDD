/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CONTROLLER;

import MODEL.AnagraficaUtente;
import MODEL.BibliotecaDataLayerMysqlImpl;
import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.iw.framework.result.TemplateManagerException;
import org.iw.framework.result.TemplateResult;
import org.iw.framework.security.SecurityLayer;

/**
 *
 * @author h00k
 */
public class MyProfile extends BibliotecaBaseControler {

    
    
    private void action_modifica_Nazione(HttpServletRequest request, HttpServletResponse response) throws SQLException, TemplateManagerException, ParseException
    {
        BibliotecaDataLayerMysqlImpl biblc = (BibliotecaDataLayerMysqlImpl)request.getAttribute("datalayer"); 
        biblc.updateNazione(request.getParameter("nazione") , (String)SecurityLayer.checkSession(request).getAttribute("email"));
        action_default(request, response);
    
    }
    private void action_modifica_luogodinascita(HttpServletRequest request, HttpServletResponse response) throws SQLException, TemplateManagerException, ParseException
    {
        BibliotecaDataLayerMysqlImpl biblc = (BibliotecaDataLayerMysqlImpl)request.getAttribute("datalayer"); 
        biblc.updateLuogoDiNascita(request.getParameter("luogodinascita") , (String)SecurityLayer.checkSession(request).getAttribute("email"));
        action_default(request, response);
    
    }
    private void action_modifica_data_di_nascita(HttpServletRequest request, HttpServletResponse response) throws SQLException, TemplateManagerException, ParseException
    {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
        java.util.Date date = sdf.parse(request.getParameter("datadinascita"));
        
        
        java.sql.Date sqlDate = new java.sql.Date(date.getTime());
        BibliotecaDataLayerMysqlImpl biblc = (BibliotecaDataLayerMysqlImpl)request.getAttribute("datalayer"); 
        biblc.updateDataDiNascita(sqlDate , (String)SecurityLayer.checkSession(request).getAttribute("email"));
        action_default(request, response);
    }
            
    private void action_modifica_cf(HttpServletRequest request, HttpServletResponse response) throws SQLException, TemplateManagerException
    {
        BibliotecaDataLayerMysqlImpl biblc = (BibliotecaDataLayerMysqlImpl)request.getAttribute("datalayer"); 
        biblc.updateCfUtente((String)request.getParameter("cf"), (String)SecurityLayer.checkSession(request).getAttribute("email"));
        action_default(request, response);
    }
            
    private void action_modifica_cognome(HttpServletRequest request, HttpServletResponse response) throws SQLException, TemplateManagerException
    {
        BibliotecaDataLayerMysqlImpl biblc = (BibliotecaDataLayerMysqlImpl)request.getAttribute("datalayer"); 
        biblc.updateCognomeUtente((String)request.getParameter("cognome"), (String)SecurityLayer.checkSession(request).getAttribute("email"));
        action_default(request, response);
    }
            
            
    private void action_modifica_nome(HttpServletRequest request, HttpServletResponse response) throws SQLException, TemplateManagerException
    {
        BibliotecaDataLayerMysqlImpl biblc = (BibliotecaDataLayerMysqlImpl)request.getAttribute("datalayer"); 
        biblc.updateNomeUtente((String)request.getParameter("nome"), (String)SecurityLayer.checkSession(request).getAttribute("email"));
        action_default(request, response);
    
    }
    private void action_default(HttpServletRequest request, HttpServletResponse response) throws SQLException, TemplateManagerException
    {
        TemplateResult template = new TemplateResult(getServletContext());
        BibliotecaDataLayerMysqlImpl biblc = (BibliotecaDataLayerMysqlImpl)request.getAttribute("datalayer");  
        AnagraficaUtente utente = biblc.getMyProfile((String)SecurityLayer.checkSession(request).getAttribute("email"));
        
        request.setAttribute("utente", utente);
        template.activate("myprofile.ftl.html", request, response);
    
    
    }
    
    
    private void action_error(HttpServletRequest request, HttpServletResponse response) throws IOException
    {
        response.sendRedirect("Home");
        
    }
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    {
        try
        {
            if(SecurityLayer.checkSession(request)!= null)
            {
                     if(request.getParameter("nome")!= null)
                        action_modifica_nome(request,response);
                else if (request.getParameter("cognome")!= null)   
                        action_modifica_cognome(request,response);
                else if   (request.getParameter("cf")!= null)   
                        action_modifica_cf(request,response);
                else if   (request.getParameter("datadinascita")!= null)   
                        action_modifica_data_di_nascita(request,response);
                else if   (request.getParameter("luogodinascita")!= null)   
                        action_modifica_luogodinascita(request,response);
                else if   (request.getParameter("nazione")!= null)   
                        action_modifica_Nazione(request,response);
                
                
                else   
                    action_default(request,response);
            }
            else
                action_error(request,response);
        }
        catch (SQLException | TemplateManagerException | IOException | ParseException ex) 
        {
            Logger.getLogger(MyProfile.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    
    }

    
    @Override
    public String getServletInfo() {
        return "MyProfile Servlet";
    }// </editor-fold>

}
