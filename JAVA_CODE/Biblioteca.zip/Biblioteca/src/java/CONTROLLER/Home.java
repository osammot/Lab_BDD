package CONTROLLER;

import MODEL.BibliotecaDataLayerMysqlImpl;
import MODEL.Pubblicazione;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.iw.framework.result.TemplateManagerException;
import org.iw.framework.result.TemplateResult;

/**
 *
 * @author h00k
 */
public class Home extends BibliotecaBaseControler{

    
    @Override
    protected void processRequest(HttpServletRequest request, HttpServletResponse response) {
    
        
    BibliotecaDataLayerMysqlImpl biblc = (BibliotecaDataLayerMysqlImpl)request.getAttribute("datalayer");   
        
        try 
        {   
            TemplateResult template = new TemplateResult(getServletContext());
            
            List<Pubblicazione> listaUltimeDieci = biblc.getUltimeDieciPublicazioni();
            
            request.setAttribute("listapubblicazioni",listaUltimeDieci );
            template.activate("home.html", request, response);
        
        
        } catch (TemplateManagerException ex) {
            Logger.getLogger(Home.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Home.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

   
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
