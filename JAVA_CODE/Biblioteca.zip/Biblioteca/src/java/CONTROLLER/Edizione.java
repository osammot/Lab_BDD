/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CONTROLLER;

import MODEL.BibliotecaDataLayerMysqlImpl;
import MODEL.Sorgente;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.iw.framework.result.TemplateManagerException;
import org.iw.framework.result.TemplateResult;

/**
 *
 * @author h00k
 */
public class Edizione extends BibliotecaBaseControler {

    
    private void action_get_edizione(HttpServletRequest request, HttpServletResponse response) throws SQLException, TemplateManagerException
    {
        BibliotecaDataLayerMysqlImpl biblc = (BibliotecaDataLayerMysqlImpl)request.getAttribute("datalayer");   
        TemplateResult template = new TemplateResult(getServletContext());
         
        
        List<Sorgente> listaSorgenti = biblc.getSorgenteByISBN(Integer.parseInt(request.getParameter("numEdizione")));
        
        MODEL.Edizione edizione = biblc.getEdizioneByISBN(Integer.parseInt(request.getParameter("numEdizione")));
        request.setAttribute("edizione", edizione) ;
        request.setAttribute("listaSorgenti", listaSorgenti) ;
        template.activate("edizione.ftl.html", request, response);
    }
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    {
        try 
        {
            if(request.getParameter("numEdizione")!= null )
                action_get_edizione(request, response);
        } 
        catch (SQLException | TemplateManagerException ex) 
        {
            Logger.getLogger(Edizione.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }

   
    @Override
    public String getServletInfo() {
        return "Servlet Edizione";
    }// </editor-fold>

}
