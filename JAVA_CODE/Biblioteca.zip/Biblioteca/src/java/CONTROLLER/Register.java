/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CONTROLLER;

import MODEL.BibliotecaDataLayerMysqlImpl;
import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.iw.framework.result.TemplateManagerException;
import org.iw.framework.result.TemplateResult;
import org.iw.framework.security.SecurityLayer;

/**
 *
 * @author h00k
 */
public class Register extends BibliotecaBaseControler {

     private void action_register(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ParseException, TemplateManagerException
     {
         
     if (   request.getParameter("email") != null && !(request.getParameter("email").isEmpty()) &&
            request.getParameter("password") != null && !(request.getParameter("password").isEmpty())&&
            request.getParameter("nome") != null && !(request.getParameter("nome").isEmpty()) &&
            request.getParameter("cognome") != null && !(request.getParameter("cognome").isEmpty()) &&
            request.getParameter("cf") != null && !(request.getParameter("cf").isEmpty())&&
             request.getParameter("datanascita") != null && !(request.getParameter("datanascita").isEmpty()) &&
            request.getParameter("luogonascita") != null && !(request.getParameter("luogonascita").isEmpty()) &&
            request.getParameter("nazione") != null && !(request.getParameter("nazione").isEmpty()) 
        )
           
     {
            BibliotecaDataLayerMysqlImpl biblc = (BibliotecaDataLayerMysqlImpl)request.getAttribute("datalayer");  
           
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
            java.util.Date date = sdf.parse(request.getParameter("datanascita"));
            java.sql.Date sqlDate = new java.sql.Date(date.getTime());
            
            String email        = request.getParameter("email");
            String password     = request.getParameter("password");
            String nome         = request.getParameter("nome");
            String cognome      = request.getParameter("cognome");
            String cf           = request.getParameter("cf");
            String luogonascita  = request.getParameter("luogonascita");
            String nazione      = request.getParameter("nazione");
            
            biblc.registrazione(email, password, nome, cognome, cf,sqlDate, luogonascita, nazione);
            SecurityLayer.createSession(request, email);
            response.sendRedirect("Home");
           
     }
   
     else action_default(request, response);
     }
    
    private void action_default(HttpServletRequest request, HttpServletResponse response) throws TemplateManagerException
    {
    
     
            
            TemplateResult template = new TemplateResult(getServletContext());
            template.activate("register.html", request, response);
             
        
        
    }
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    {
      try {
        if(request.getParameter("rec") != null)
          
                action_register(request,response);
        
        
        else
        action_default(request, response);
      } catch (SQLException ex) {
            Logger.getLogger(Register.class.getName()).log(Level.SEVERE, null, ex);
        } catch (TemplateManagerException ex) {
             Logger.getLogger(Register.class.getName()).log(Level.SEVERE, null, ex);
         } catch (IOException ex) {
             Logger.getLogger(Register.class.getName()).log(Level.SEVERE, null, ex);
         } catch (ParseException ex) {
             Logger.getLogger(Register.class.getName()).log(Level.SEVERE, null, ex);
         }
            
    }
    

    
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
