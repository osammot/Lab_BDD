package CONTROLLER;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import MODEL.BibliotecaDataLayerMysqlImpl;
import freemarker.core.ParseException;
import freemarker.template.MalformedTemplateNameException;
import freemarker.template.TemplateException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import org.iw.framework.result.FailureResult;
import org.iw.framework.result.TemplateManagerException;
import org.iw.framework.security.SecurityLayer;





public abstract class BibliotecaBaseControler extends HttpServlet {

    @Resource(name = "jdbc/BIBLIOTECA")
    private DataSource ds;
    
    protected abstract void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException;

    private void processBaseRequest(HttpServletRequest request, HttpServletResponse response) throws IOException, ParseException, UnsupportedEncodingException, MalformedTemplateNameException, TemplateException, TemplateManagerException {
      
        try ( BibliotecaDataLayerMysqlImpl datalayer = new BibliotecaDataLayerMysqlImpl(ds)) {
            datalayer.init();
            request.setAttribute("datalayer", datalayer);
            
            if(SecurityLayer.checkSession(request) != null)
            {
                request.setAttribute("email", SecurityLayer.checkSession(request).getAttribute("email"));
            
            }
            
            
            processRequest(request, response);
        } catch (Exception ex) {
            ex.printStackTrace(); //for debugging only
            (new FailureResult(getServletContext())).activate(
                    (ex.getMessage() != null || ex.getCause() == null) ? ex.getMessage() : ex.getCause().getMessage(), request, response);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ParseException, UnsupportedEncodingException, MalformedTemplateNameException {
        try {
            processBaseRequest(request, response);
        } catch (TemplateException | TemplateManagerException ex) {
            Logger.getLogger(BibliotecaBaseControler.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ParseException, UnsupportedEncodingException, MalformedTemplateNameException {
        try 
        {
            processBaseRequest(request, response);
        } catch (TemplateException | TemplateManagerException ex) {
            Logger.getLogger(BibliotecaBaseControler.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    
}
