/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CONTROLLER;

import MODEL.BibliotecaDataLayerMysqlImpl;
import MODEL.Pubblicazione;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.iw.framework.result.TemplateManagerException;
import org.iw.framework.result.TemplateResult;

/**
 *
 * @author h00k
 */
public class Autore extends BibliotecaBaseControler {

    private void action_default(HttpServletRequest request , HttpServletResponse response) throws SQLException, TemplateManagerException
    {
        BibliotecaDataLayerMysqlImpl biblc = (BibliotecaDataLayerMysqlImpl)request.getAttribute("datalayer");   
        TemplateResult template = new TemplateResult(getServletContext());
        MODEL.Autore aut = biblc.getAutoreByID(Integer.parseInt(request.getParameter("idAutore")));
        List<Pubblicazione> listaPubb = biblc.getPubblicazioniByAutore(Integer.parseInt(request.getParameter("idAutore")));
 
        request.setAttribute("autore", aut);
        request.setAttribute("listapubb",listaPubb);
        
        template.activate("autore.ftl.html", request, response);
    }
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    {
        try 
        {
            if(request.getParameter("idAutore")!= null)
                action_default(request, response);
        }
        catch (SQLException ex) 
        {
            Logger.getLogger(Autore.class.getName()).log(Level.SEVERE, null, ex);
        } catch (TemplateManagerException ex) {
            Logger.getLogger(Autore.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    
    @Override
    public String getServletInfo() 
    {
        return "Short description";
    }// </editor-fold>

}
