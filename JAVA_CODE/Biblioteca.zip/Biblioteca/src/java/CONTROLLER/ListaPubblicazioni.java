/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CONTROLLER;

import MODEL.BibliotecaDataLayerMysqlImpl;
import MODEL.Pubblicazione;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.iw.framework.data.BibliotecaDataLayer;
import org.iw.framework.result.TemplateManagerException;
import org.iw.framework.result.TemplateResult;

/**
 *
 * @author h00k
 */
public class ListaPubblicazioni extends BibliotecaBaseControler {

    
    private void action_default(HttpServletRequest request, HttpServletResponse response) throws SQLException, TemplateManagerException
    {
    
        TemplateResult template = new TemplateResult(getServletContext());
                
        BibliotecaDataLayer bibliodl = (BibliotecaDataLayerMysqlImpl)request.getAttribute("datalayer");  
        
        List<Pubblicazione> listaPubblicazioni = bibliodl.getListaPublicazioni();
        
        request.setAttribute("listapubblicazioni",listaPubblicazioni );
        
        template.activate("listapubblicazioni.html", request, response);
        
    }
  
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    {
    
        try 
        {
        
            action_default(request,response);
        
        } catch (SQLException | TemplateManagerException ex) {
            Logger.getLogger(ListaPubblicazioni.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    
    }

    
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
