package org.iw.framework.data;

import MODEL.Pubblicazione;
import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

/**
 *
 * @author h00k
 */
public interface BibliotecaDataLayer 
{
    
    public void registrazione(String email , String password , String nome , String cognome ,String cf ,Date data, String luogonascita , String nazione) throws SQLException ;
    public boolean login(String email , String password ) throws SQLException ;
    
    public List<Pubblicazione> getListaPublicazioni()throws SQLException;
    public List<Pubblicazione> getUltimeDieciPublicazioni()throws SQLException;
    
    
    
    void init() throws DataLayerException;
    void destroy();
    

}
