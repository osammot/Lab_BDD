/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MODEL;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author h00k
 */
public class Edizione {

    int ISBN;
    int pubblicazione;
    int numeropagine;
    String lingua ;
    String parolechiave;
    Date data ;
    

    public Edizione(int ISBN, int pubblicazione, int numeropagine, String lingua, String parolechiave, Date data) {
        this.ISBN = ISBN;
        this.pubblicazione = pubblicazione;
        this.numeropagine = numeropagine;
        this.lingua = lingua;
        this.parolechiave = parolechiave;
        this.data = data;
    }
    
    public Edizione() {
        this.ISBN = 0;
        this.pubblicazione = 0;
        this.numeropagine = 0;
        this.lingua = "";
        this.parolechiave = "";
        this.data = null;
    }

    public int getISBN() {
        return ISBN;
    }

    public void setISBN(int ISBN) {
        this.ISBN = ISBN;
    }

    public int getPubblicazione() {
        return pubblicazione;
    }

    public void setPubblicazione(int pubblicazione) {
        this.pubblicazione = pubblicazione;
    }

    public int getNumeropagine() {
        return numeropagine;
    }

    public void setNumeropagine(int numeropagine) {
        this.numeropagine = numeropagine;
    }

    public String getLingua() {
        return lingua;
    }

    public void setLingua(String lingua) {
        this.lingua = lingua;
    }

    public String getParolechiave() {
        return parolechiave;
    }

    public void setParolechiave(String parolechiave) {
        this.parolechiave = parolechiave;
    }

    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }

    
    
    
}
