/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MODEL;

import java.util.Date;

/**
 *
 * @author h00k
 */
public class AnagraficaUtente {
    
    String nome ;
    String cognome ;
    String cf ;
    Date datadinascita ;
    String luogodinascita;
    String nazione ;

    public AnagraficaUtente(String nome, String cognome, String cf, Date datadinascita, String luogodinascita, String nazione) {
        this.nome = nome;
        this.cognome = cognome;
        this.cf = cf;
        this.datadinascita = datadinascita;
        this.luogodinascita = luogodinascita;
        this.nazione = nazione;
    }

    public AnagraficaUtente() {
    
        this.nome ="";
        this.cognome = "";
        this.cf = "";
        this.datadinascita = null ;
        this.luogodinascita = "";
        this.nazione = "";   
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCognome() {
        return cognome;
    }

    public void setCognome(String cognome) {
        this.cognome = cognome;
    }

    public String getCf() {
        return cf;
    }

    public void setCf(String cf) {
        this.cf = cf;
    }

    public Date getDatadinascita() {
        return datadinascita;
    }

    public void setDatadinascita(Date datadinascita) {
        this.datadinascita = datadinascita;
    }

    public String getLuogodinascita() {
        return luogodinascita;
    }

    public void setLuogodinascita(String luogodinascita) {
        this.luogodinascita = luogodinascita;
    }

    public String getNazione() {
        return nazione;
    }

    public void setNazione(String nazione) {
        this.nazione = nazione;
    }  
    
}
