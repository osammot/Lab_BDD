/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MODEL;

/**
 *
 * @author h00k
 */
public class Sorgente 
{
    private int idSorgente ;
    private String tipo ;
    private String uri ;
    private String formato ;
    private String descrizione;

    public Sorgente(int idSorgente, String tipo, String uri, String formato, String descrizione) 
    {
        this.idSorgente = idSorgente;
        this.tipo = tipo;
        this.uri = uri;
        this.formato = formato;
        this.descrizione = descrizione;
    }
    
    public Sorgente()
    {
        this.idSorgente = 0;
        this.tipo = "";
        this.uri = "";
        this.formato = "";
        this.descrizione = "";
    }

    public int getIdSorgente() 
    {
        return idSorgente;
    }

    public void setIdSorgente(int idSorgente) 
    {
        this.idSorgente = idSorgente;
    }

    public String getTipo() 
    {
        return tipo;
    }

    public void setTipo(String tipo) 
    {
        this.tipo = tipo;
    }

    public String getUri() 
    {
        return uri;
    }

    public void setUri(String uri) 
    {
        this.uri = uri;
    }

    public String getFormato() 
    {
        return formato;
    }

    public void setFormato(String formato) 
    {
        this.formato = formato;
    }

    public String getDescrizione() 
    {
        return descrizione;
    }

    public void setDescrizione(String descrizione) 
    {
        this.descrizione = descrizione;
    }
    
    
    
}
