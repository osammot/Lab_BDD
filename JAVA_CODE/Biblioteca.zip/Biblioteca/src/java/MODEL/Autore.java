/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MODEL;

/**
 *
 * @author h00k
 */
public class Autore 
{
    
    private int idAutore ;
    
    private String nome;
    
    private String cognome;

    public Autore() 
    {
        this.nome = "";
        this.cognome = "";
        this.idAutore = 0 ;
    }

    
    
    public Autore(String nome, String cognome,int id) 
    {
        this.nome = nome;
        this.cognome = cognome;
        this.idAutore = id ;
    }

    public int getIdAutore() 
    {
        return idAutore;
    }

    public void setIdAutore(int idAutore) 
    {
        this.idAutore = idAutore;
    }
    
    public String getNome() 
    {
        return nome;
    }

    public void setNome(String nome) 
    {
        this.nome = nome;
    }

    public String getCognome() 
    {
        return cognome;
    }

    public void setCognome(String cognome) 
    {
        this.cognome = cognome;
    }
    
}
