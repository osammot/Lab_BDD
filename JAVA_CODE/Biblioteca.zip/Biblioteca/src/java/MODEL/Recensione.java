/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MODEL;

import java.util.Date;

/**
 *
 * @author h00k
 */
public class Recensione 
{
    private int idRecensione;
    private int idPubblicazione;
    private String utente ;
    private Date data;
    private String testo;
    private String stato;

    public Recensione()
    {
        this.data = null;
        this.idPubblicazione=0;
        this.idRecensione=0;
        this.stato="";
        this.testo="";
        this.utente="";
    }

    public Recensione(int idRecensione, int idPubblicazione, String utente, Date data, String testo, String stato) 
    {
        this.idRecensione = idRecensione;
        this.idPubblicazione = idPubblicazione;
        this.utente = utente;
        this.data = data;
        this.testo = testo;
        this.stato = stato;
    }

    public int getIdRecensione() 
    {
        return idRecensione;
    }

    public void setIdRecensione(int idRecensione) 
    {
        this.idRecensione = idRecensione;
    }

    public int getIdPubblicazione() 
    {
        return idPubblicazione;
    }

    public void setIdPubblicazione(int idPubblicazione) 
    {
        this.idPubblicazione = idPubblicazione;
    }

    public String getUtente() 
    {
        return utente;
    }

    public void setUtente(String utente) 
    {
        this.utente = utente;
    }

    public Date getData() 
    {
        return data;
    }

    public void setData(Date data) 
    {
        this.data = data;
    }

    public String getTesto() 
    {
        return testo;
    }

    public void setTesto(String testo) 
    {
        this.testo = testo;
    }

    public String getStato() 
    {
        return stato;
    }

    public void setStato(String stato) 
    {
        this.stato = stato;
    }
    
    
    
    
    
    
}
