package MODEL;

import java.sql.CallableStatement;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.naming.NamingException;
import javax.sql.DataSource;
import org.iw.framework.data.DataLayerException;
import org.iw.framework.data.DataLayerMysqlImpl;
import org.iw.framework.data.BibliotecaDataLayer;


public class BibliotecaDataLayerMysqlImpl extends DataLayerMysqlImpl implements BibliotecaDataLayer
{   
    private CallableStatement registrazione , login , profilo;
    
    private CallableStatement modificaNomeUtente , modificaCognomeUtente , modificaCfUtente , modificaDataDiNascita ,modificaLuogoDiNascita , modificaNazione;
    
    //private CallableStatement searchByISBN ;
    private CallableStatement getListaPubblicazioni , getUltimeDieci;
    private CallableStatement singolaPubblicazione ;
    private CallableStatement getEdizionibytitolo;
    private CallableStatement getAutoriPubblicazione;
    private CallableStatement getRecensioniApprovate ,inserisciRecensione ;
    private CallableStatement like ;
    private CallableStatement pubblicazioniAutore ;
    private CallableStatement getAutoreById ;
    private CallableStatement getEdizione , sorgenteEdizione ;
    private ResultSet rs ;
    
    public BibliotecaDataLayerMysqlImpl(DataSource datasource) throws SQLException, NamingException {
        super(datasource);
    }
    
    @Override
    public void init() throws DataLayerException
    {
        try
        {
           super.init();
           //PROCEDURE UTENTE
           registrazione = connection.prepareCall("CALL REGISTRAZIONE(?,?,?,?,?,?,?,?)");
           login = connection.prepareCall("CALL LOGG(?,?,?)");
           profilo = connection.prepareCall("CALL GETPROFILE(?)");
           
           //PROCEDURE MODIFICA ANAGRAFICA UTENTE
           
           modificaNomeUtente = connection.prepareCall("CALL UPDATENOME(?,?)");
           modificaCognomeUtente = connection.prepareCall("CALL UPDATECOGNOME(?,?)");
           modificaCfUtente = connection.prepareCall("CALL UPDATECF(?,?)");
           modificaDataDiNascita = connection.prepareCall("CALL UPDATEDATADINASCITA(?,?)");
           modificaLuogoDiNascita = connection.prepareCall("CALL UPDATELUOGODINASCITA(?,?)");
           modificaNazione = connection.prepareCall("CALL UPDATENAZIONE(?,?)");
           
           //PROCEDURE SEARCH
           
           //searchByISBN = connection.prepareCall("CALL SEARCHBYISBN(?)");
           
           
           
           //PROCEDURE LISTA PUBBLICAZIONI
           getListaPubblicazioni = connection.prepareCall("CALL GETLISTAPUBBLICAZIONI()");
           getUltimeDieci = connection.prepareCall("CALL ULTIMEDIECI()");
           
           //PROCEDURE SINGOLA PUBBLICAZIONE
           singolaPubblicazione = connection.prepareCall("CALL GETPUBBLICAZIONE(?)");
           getAutoriPubblicazione = connection.prepareCall("CALL GETAUTORI(?)");
           getEdizionibytitolo = connection.prepareCall("CALL GETEDIZIONIBYTITOLO (?) ");
           getRecensioniApprovate = connection.prepareCall("CALL GETRECENSIONIAPPROVATE(?)");
           inserisciRecensione = connection.prepareCall("CALL ADDRECENSIONE(?,?,?)");
           like = connection.prepareCall("CALL INSERTLIKE(?,?)");
           
           
           
           pubblicazioniAutore = connection.prepareCall("CALL GETPUBBLICAZIONEBYAUTORE(?)");
           getAutoreById = connection.prepareCall("CALL GETAUTOREBYID(?)");
        
           //PROCEDURE EDIZIONE
           
           getEdizione = connection.prepareCall("CALL GETEDIZIONEBYISBN(?)");
           sorgenteEdizione = connection.prepareCall("CALL GETSORGENTEBYISBN(?)");
           
        }
        catch (SQLException ex)
        {
            throw new DataLayerException("Error initializing biblioteca data layer", ex);
        }
    }
    
        //METODI MODIFICA ANAGRAFICA UTENTE
        
        public void updateNomeUtente(String nome , String email) throws SQLException
        {
           modificaNomeUtente.setString(1, nome);
           modificaNomeUtente.setString(2, email);
           modificaNomeUtente.executeQuery();
        }
  
        public void updateCognomeUtente(String cognome , String email)throws SQLException
        {
            modificaCognomeUtente.setString(1, cognome);
            modificaCognomeUtente.setString(2, email);
            modificaCognomeUtente.execute();
        }
        
        public void updateCfUtente(String nome , String email) throws SQLException
        {
            modificaCfUtente.setString(1, nome);
            modificaCfUtente.setString(2, email);
            modificaCfUtente.execute();
        }
        
        public void updateDataDiNascita(Date data , String email)throws SQLException
        {
            modificaDataDiNascita.setDate(1, data);
            modificaDataDiNascita.setString(2, email);
            modificaDataDiNascita.execute();
        }
        
        public void updateLuogoDiNascita(String luogo , String email ) throws SQLException
        {
            modificaLuogoDiNascita.setString(1, luogo);
            modificaLuogoDiNascita.setString(2, email);
            modificaLuogoDiNascita.execute();
        }
        
        public void updateNazione(String nazione ,String email) throws SQLException
        {
            modificaNazione.setString(1 , nazione);
            modificaNazione.setString(2, email);
            modificaNazione.execute();
        }
        
        //METODI PER RICERCA
        
        
        
        
        public List<Sorgente> getSorgenteByISBN(int isbn) throws SQLException
        {
        List<Sorgente> listasorg = new ArrayList<>();
        sorgenteEdizione.setInt(1, isbn);
        rs = sorgenteEdizione.executeQuery();
        while(rs.next())
        {
            Sorgente sor = new Sorgente();
            sor.setIdSorgente(rs.getInt("id_sorgente"));
            sor.setTipo(rs.getString("tipo"));
            sor.setUri(rs.getString("uri"));
            sor.setFormato(rs.getString("formato"));
            sor.setDescrizione(rs.getString("descrizione"));
            listasorg.add(sor);
        
        }
        
        return listasorg ;
        }
    
        public Autore getAutoreByID(int idAutore) throws SQLException
        {
            Autore aut = new Autore();
            getAutoreById.setInt(1, idAutore);
            rs = getAutoreById.executeQuery();
            if(rs.next())
            {
                aut.setIdAutore(idAutore);
                aut.setNome(rs.getString("nome"));
                aut.setCognome(rs.getString("cognome"));
                
            }
            return aut;
        }
    
        public List<Pubblicazione> getPubblicazioniByAutore(int idAutore) throws SQLException
        {
            List<Pubblicazione> lista = new ArrayList<>();
            pubblicazioniAutore.setInt(1, idAutore);
            rs = pubblicazioniAutore.executeQuery();
            while(rs.next())
            {
                Pubblicazione pubb = new Pubblicazione();
                pubb.setDatainserimento(rs.getDate("data_inserimento"));
                pubb.setEditore(rs.getString("editore"));
                pubb.setId(idAutore);
                pubb.setNumlike(rs.getInt("numlike"));
                pubb.setTitolo(rs.getString("titolo"));
                
                lista.add(pubb);
            }
            return lista ;
        }
    
    
        public void insertLike(String utente , int idPubb) throws SQLException
        {
        like.setString(1, utente);
        like.setInt(2, idPubb);
        like.execute();
        }
        
        public void insertRecesione(int idPubb , String utente , String testo) throws SQLException
        {
            
            inserisciRecensione.setInt(1, idPubb);
            inserisciRecensione.setString(2, utente);
            inserisciRecensione.setString(3, testo);
            System.out.println(inserisciRecensione);
            inserisciRecensione.execute();
        
        }
        /*
        recupera le recensioni approvate per una pubblicazione
        */
        public List<Recensione> getRecensioniApprovate(String titoloPubb) throws SQLException
        {
            List<Recensione> listaRec = new ArrayList<>();
            
            getRecensioniApprovate.setString(1, titoloPubb);
            rs = getRecensioniApprovate.executeQuery();
            
            while(rs.next())
            {
                Recensione rec = new Recensione();
                rec.setData(rs.getDate("data_inserimento"));
                rec.setIdPubblicazione(rs.getInt("pubblicazione"));
                rec.setIdRecensione(rs.getInt("id_recensione"));
                rec.setStato(rs.getString("stato"));
                rec.setTesto(rs.getString("testo"));
                rec.setUtente(rs.getString("utente"));
                listaRec.add(rec);
            }
            
            return listaRec;
        }
        
        /*
        recupera tutti gli autori di una pubblicazione
        */
        public List<Autore> getAutoriPubblicazioneByTitolo(String titolo) throws SQLException
        {
            List<Autore> listaAutori = new ArrayList<>();
            getAutoriPubblicazione.setString(1, titolo);
            rs = getAutoriPubblicazione.executeQuery();
            
            while(rs.next())
            {
                Autore aut = new Autore();
                aut.setIdAutore(rs.getInt("id_autore"));
                aut.setNome(rs.getString("nome"));
                aut.setCognome(rs.getString("cognome"));
                listaAutori.add(aut);
            }
            
            return listaAutori ;
        }
    
        /*
        recupera le edizioni di una pubblicazione dato il titolo della pubblicazione
        */
        public List<Edizione> getEdizioniByTitolo(String titoloPubb) throws SQLException
        {
            List<Edizione> listaEdizione = new ArrayList<>();
            getEdizionibytitolo.setString(1, titoloPubb);
            rs = getEdizionibytitolo.executeQuery();
            while(rs.next())
            {
                Edizione ed = new Edizione();
                ed.setData(rs.getDate("data"));
                ed.setISBN(rs.getInt("ISBN"));
                ed.setLingua(rs.getString("lingua"));
                ed.setNumeropagine(rs.getInt("numero_pagine"));
                ed.setParolechiave(rs.getString("parole_chiave"));
                ed.setPubblicazione(rs.getInt("pubblicazione"));
                
                listaEdizione.add(ed);
            }
            return listaEdizione ;
        }
                
                
        /*
        recupera  i dati di una pubblicazione dato il titolo
        */
        public Pubblicazione getSinglePubblicazione ( String titolo) throws SQLException
        {
            Pubblicazione pubblicazione = new Pubblicazione();
            singolaPubblicazione.setString(1, titolo);
            rs = singolaPubblicazione.executeQuery();
            
            if(rs.next())
            {
               pubblicazione.setDatainserimento(rs.getDate("data_inserimento"));
               pubblicazione.setEditore(rs.getString("editore"));
               pubblicazione.setId(rs.getInt("id_pubblicazione"));
               pubblicazione.setNumlike(rs.getInt("numlike"));
               pubblicazione.setTitolo(titolo);
            }
            return pubblicazione ;
        }
    
        
        
        //METODI EDIZIONE
        
        public Edizione getEdizioneByISBN( int isbn ) throws SQLException
        {
            Edizione ed = new Edizione();
            getEdizione.setInt(1, isbn);
            rs = getEdizione.executeQuery() ;
            
            if( rs.next())
            {
                ed.setData(rs.getDate("data"));
                ed.setISBN(isbn);
                ed.setLingua(rs.getString("lingua"));
                ed.setNumeropagine(rs.getInt("numero_pagine"));
                ed.setParolechiave(rs.getString("parole_chiave"));
                ed.setPubblicazione(rs.getInt("pubblicazione"));
            }
            return ed ;
        
        }
        
        // METODI UTENTE
        @Override
        public boolean login(String email , String password ) throws SQLException 
        {
            login.setString(1, email );
            login.setString(2, password );
            login.registerOutParameter(3,java.sql.Types.BOOLEAN);
            
            login.executeQuery();
            boolean isCorrect = login.getBoolean(3);
            
            return isCorrect ;
        }
        
        @Override
        public void registrazione(String email , String password , String nome , String cognome ,String cf ,Date data, String luogonascita , String nazione) throws SQLException{
        
            registrazione.setString(1,email );
            registrazione.setString(2,password );
            registrazione.setString(3, nome);
            registrazione.setString(4, cognome);
            registrazione.setString(5, cf);
            registrazione.setDate(6, data );
            registrazione.setString(7,luogonascita );
            registrazione.setString(8, nazione);

            registrazione.execute();
        
        }
        
        public AnagraficaUtente getMyProfile(String email) throws SQLException
        {
            AnagraficaUtente utente = new AnagraficaUtente();
            
            profilo.setString(1, email);
            rs = profilo.executeQuery();
            if(rs.next())
            {
                utente.setNome(rs.getString("nome"));
                utente.setCognome(rs.getString("cognome"));
                utente.setDatadinascita(rs.getDate("data_di_nascita"));
                utente.setLuogodinascita(rs.getString("luogo_di_nascita"));
                utente.setCf(rs.getString("cf"));
                utente.setNazione(rs.getString("nazione"));
            }
            
            return utente ;
        }
        
        
        @Override
        public List<Pubblicazione> getListaPublicazioni() throws SQLException
        {
            List<Pubblicazione> listaPubblicazioni = new ArrayList<>();
            
            rs = getListaPubblicazioni.executeQuery();
            
            
            while (rs.next())
            {
                Pubblicazione pub = new Pubblicazione();
                pub.setId(rs.getInt("id_pubblicazione"));
                pub.setTitolo(rs.getString("titolo"));
                pub.setEditore(rs.getString("editore"));
                pub.setDatainserimento(rs.getDate("data_inserimento"));
                pub.setNumlike(rs.getInt("numlike"));
            
                listaPubblicazioni.add(pub);
            }
            return listaPubblicazioni ;
        }
    
    
           public List<Pubblicazione> getUltimeDieciPublicazioni()throws SQLException{
           
               List<Pubblicazione> ultimedieci = new ArrayList<>();
            
            rs = getUltimeDieci.executeQuery();
            
            
            while (rs.next())
            {
                Pubblicazione pub = new Pubblicazione();
                pub.setId(rs.getInt("id_pubblicazione"));
                pub.setTitolo(rs.getString("titolo"));
                pub.setEditore(rs.getString("editore"));
                pub.setDatainserimento(rs.getDate("data_inserimento"));
                pub.setNumlike(rs.getInt("numlike"));
            
                ultimedieci.add(pub);
            }
            return ultimedieci ;
           }
        
        
    @Override
    public void destroy() {
       
        try {
            registrazione.close();
            login.close();
            
            
        } catch (SQLException ex) {
         
        }
        super.destroy();
    }

    

}
